LumaStitch multi-hooping package

Sew numbered files in manifest order. Each begins with a temporary basting frame and shared registration crosses in the registration thread, then a STOP before design colors. Align the shared pair of crosses with the previous neighboring hooping; the two points establish position and rotation. The symmetric frame fixes machine-file centering. Do not remove it from the program or use automatic resize/fit on the machine. Remove temporary basting/registration thread after assembly. Registration-only hoopings bridge empty areas of the rectangular layout.

Coordinates in manifest.json are millimetres in the original design. Every numbered machine file uses local coordinates centered on its stated centerMm. layout.svg is an actual-size placement template; print at 100% and verify scale. These are overlapping rectangular fields, not a machine-specific multi-position hoop format.

Stitch segments are split at ownership boundaries inside overlaps; original penetrations are retained and extra seam penetrations, locks, trims and registration stitches are added. Source sequence and stops are retained within each hooping. The numbered projects contain editable machine stitches, not reconstructed vector objects. source.lumastitch preserves the original design and settings. Changing density requires regenerating the package from the source.

Software fit and command checks do not establish physical registration accuracy. Sew a sample on the intended machine/fabric/stabilizer before a production piece.
